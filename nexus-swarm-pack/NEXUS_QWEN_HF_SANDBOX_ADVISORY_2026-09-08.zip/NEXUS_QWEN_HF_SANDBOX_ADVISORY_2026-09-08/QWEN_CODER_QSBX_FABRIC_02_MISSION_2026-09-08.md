# QWEN CODER — NEXT LONG-RUN EXPERIMENTAL MISSION
## `QSBX-FABRIC-02 — Truth Repair → Capability Census → Boundary Map`

**Authority:** Clock-B experimental only  
**Do not:** bypass provider controls, spend paid compute without explicit operator grant, mutate Clock-A, treat HF Bucket as custody, or call a stubbed effect "verified".

---

## 0. Mission objective

Take the current Qwen/Hermes/HF scaffold and turn it into a **truthful experimental fabric**.

The goal is not to write more architecture prose.

The goal is to:

```text
repair contradictions
→ replace success-shaped stubs with real effects
→ characterize each HF capability independently
→ map the actual Qwen sandbox boundary
→ complete one cross-node NEXUS/A100/HF task with receipts
```

A FAIL/BLOCKED result is acceptable and useful.

---

## 1. Admission freeze

Preserve:

```text
NEXUS-QWEN-HF-SANDBOX-01
= CLOCK-B

owned HF bucket write
= VERIFIED

owned dataset repo create
= VERIFIED

general HF authority
= NOT INFERRED

HF Jobs
= billing-dependent

ZeroGPU
= operator observes ~40 min/day

A100
= independent GPU lane

HF bucket
= mutable A1 artifact plane
!= custody
```

Never print token values.

---

## 2. Q0 — Truth repair

### 2.1 Secret/doc hygiene

Search repository/workspace for credential-shaped literals.

Output only:

```text
file
line
credential_class
redacted_fingerprint
tracked/untracked
```

Do not echo secret values.

Replace documentation literals with:

```text
${HF_TOKEN}
${GROQ_API_KEY}
${CEREBRAS_API_KEY}
...
```

Do not rotate credentials yourself unless explicitly authorized.

### 2.2 Reconcile stale claims

Remove/supersede:

```text
"HF Pro required for bucket writes"
"HF Pro required for gated model access"
"production-ready"
```

unless a current receipt supports the statement.

### 2.3 Fix split-env enforcement

`hf_nexus_bridge.py` must resolve:

```text
HFBUCKET_CLI
```

from environment and fail closed.

Required receipt:

```text
system huggingface_hub
admin-venv huggingface_hub
resolved hf executable
transformers import test
```

STOP Q0 if system ML environment is broken.

---

## 3. Q1 — Remove simulated effects

### 3.1 Real MCP audit

Replace `_log_to_mcp()` console-only behavior.

Required:

```text
bridge event
→ GROSS-AUDITOR actual audit/evidence tool call
→ returned tool receipt
```

Console logging may remain as secondary diagnostics.

### 3.2 Real A2A

Replace fake `delegate_to_agent()` publication.

Required control:

```text
Qwen publishes task T
→ independent recipient retrieves T
→ recipient ACKs T
→ recipient performs harmless requested read/write fixture
→ result returned with T
→ Qwen correlates result
```

If HuggingChat recipient is not reachable:

```text
A2A = BLOCKED
```

Do not simulate success.

### 3.3 Jobs adapter

Compare current `run_remote_job()` to installed `hf jobs --help` and current official syntax.

If billing/credit state blocks a harmless CPU admission job:

```text
HF_JOBS = BILLING_BLOCKED
```

Do not attempt billing bypass.

---

## 4. Q2 — Capability census

Create tiny disposable fixtures.

For each capability report:

```text
PASS
FAIL
BLOCKED
UNKNOWN
```

with a receipt.

Test:

1. owned bucket list;
2. owned bucket write → readback → SHA-256;
3. owned bucket delete → absence;
4. owned dataset repo file push → readback;
5. one controlled org resource only if clearly writable;
6. Static Space create if eligible;
7. CPU Basic/Gradio Space create only if account entitlement allows it;
8. own ZeroGPU Space fixture if eligible;
9. existing ZeroGPU API use and quota receipt;
10. HF MCP anonymous/read;
11. HF MCP authenticated write to owned disposable object;
12. HF Jobs tiny CPU admission;
13. HF Sandbox create/run/destroy if available.

Never infer one capability from another.

---

## 5. Q3 — ZeroGPU measurement

The operator reports approximately 40 minutes/day Blackwell-class ZeroGPU entitlement.

Measure rather than assume:

```text
quota_before
account/tier label if UI/API exposes it
queue delay
GPU backing identity
VRAM
allocation duration
work duration
quota charged
quota_after
```

Use a tiny GPU function.

Pre-stage all dependencies/data before GPU allocation.

Do not burn quota on compilation or downloads.

---

## 6. Q4 — Qwen sandbox boundary map

No sandbox escape attempts.

Characterize documented/ordinary capabilities only.

### Filesystem

```text
writable roots
persistent roots
ephemeral roots
mounts
large-file behavior
session-reset behavior
```

### Processes

```text
background process lifetime
ports
signals
timeouts
PTY behavior
service persistence
```

### Network

```text
DNS
HTTPS
WebSocket
SSE
MCP
owned tunnel/endpoints
large-transfer behavior
```

### Toolchain

```text
pip
venv
git
hf
node/npm if present
compilers/binaries
```

### State

Open a fresh Qwen session and re-check:

```text
workspace
venv
git
Hermes DB
env vars
credential caches
services
```

Produce `QSBX_BOUNDARY_MATRIX.json`.

---

## 7. Q5 — First real cross-node experiment

Use a harmless research artifact.

Example:

```text
Qwen
→ creates TaskEnvelope
→ publishes through real NEXUS/GROSS-AUDITOR path

A100
→ performs bounded compute/eval
→ produces artifact + SHA-256

HF
→ receives artifact in owned bucket

Qwen
→ reads artifact back
→ verifies SHA-256

independent verifier
→ confirms remote object and result
```

No source mutation required.

No Clock-A effect.

---

## 8. Required artifacts

Create:

```text
QSBX_CURRENT_REALITY.md
QSBX_CAPABILITY_MATRIX.json
QSBX_BOUNDARY_MATRIX.json
QSBX_ZERO_GPU_RECEIPT.json
QSBX_A2A_RECEIPT.json
QSBX_CROSS_NODE_RECEIPT.json
QSBX_OPEN_GAPS.md
MANIFEST.sha256
```

Never put raw credentials into any artifact.

---

## 9. Completion law

Do not report:

```text
PRODUCTION READY
```

unless all promotion gates in the advisory pass.

Valid outcomes:

```text
EXPERIMENT_READY
CAPABILITY_CHARACTERIZED
PARTIAL
BLOCKED
FAILED
PRODUCTION_BRIDGE_CANDIDATE
```

A tool returning success is not sufficient.

For remote writes:

```text
request success
→ remote object observed
→ readback hash verified
```

For delegation:

```text
local publish
→ remote receive
→ remote effect
→ returned correlated receipt
```

For ZeroGPU:

```text
Space configured
!= GPU allocated
!= task completed
```

---

## 10. Stop conditions

STOP and preserve evidence if:

```text
system ML environment breaks
unexpected paid billing starts
credential values appear in output
Clock-A resource would be mutated
HF capability requires bypassing provider restrictions
A2A target identity is ambiguous
remote effect cannot be correlated
```

Otherwise continue through Q0→Q5 autonomously.

---

## Final requested report

End with exactly:

```text
QSBX-FABRIC-02

Q0 TRUTH REPAIR =
Q1 BRIDGE TRUTH =
Q2 HF CAPABILITY CENSUS =
Q3 ZEROGPU =
Q4 SANDBOX BOUNDARY =
Q5 CROSS-NODE FABRIC =

OWNED_RESOURCE_WRITE =
HF_MCP_WRITE =
HF_JOBS =
HF_SANDBOX =
ZEROGPU_ACCOUNT_QUOTA =
ZEROGPU_GPU =
A2A =
A100_HANDOFF =
EVIDENCE_CUSTODY =

PRODUCTION_BRIDGE_CANDIDATE =
OPEN_BLOCKERS =
NEXT_OPERATOR_DECISION =
```
