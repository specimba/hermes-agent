# NEXUS-QWEN-HF-SANDBOX-01
## Experimental Fabric Advisory, Capability Matrix, and Boundary-Characterization Program

**Date:** 2026-09-08  
**Lane:** Clock-B / Experimental Fabric  
**Subject:** Qwen Coder Browser Sandbox + Hermes + Hugging Face + NEXUS MCP + external model providers  
**Status:** `OPERATIONAL / OWNED-RESOURCE WRITE VERIFIED / NOT PRODUCTION-ADMITTED`  
**Authority class:** Research / experimentation / implementation scaffold  
**Constitutional authority:** NONE  
**Evidence custody authority:** NONE  
**Production authority:** NONE  

---

# 0. Executive decision

This lane is worth preserving and expanding.

It is not merely a second coding environment. It is a useful experimental object because it combines:

- a browser-hosted Qwen Coder sandbox;
- Linux filesystem/process/package capabilities;
- Hermes-style multi-agent orchestration;
- external inference providers;
- Hugging Face repositories and Storage Buckets;
- potential ZeroGPU, Jobs, Sandboxes and MCP surfaces;
- a NEXUS/GROSS-AUDITOR MCP path;
- a separate A100 GPU lane that can serve as an independent execution/comparison node.

The intended role is:

```text
QWEN CODER SANDBOX
= experimental orchestration / integration worker

A100 / CLINE
= heavyweight GPU forge / independent worker

HF BUCKETS
= mutable A1 artifact/staging plane

HF REPOSITORIES
= versioned publication / dataset / model plane

HF SPACES / ZEROGPU / JOBS / SANDBOXES
= external execution planes, separately admitted

NEXUS MCP / GROSS-AUDITOR
= governed interface / task / evidence-reporting plane

ARCHIVIST / R0
= evidence custody

NEXUS AUTHORITY KERNEL
= authorization / consequence authority
```

The lane must remain **Clock-B** unless a later explicit grant admits a particular effect into Clock-A.

---

# 1. Governing doctrine

The purpose of this lane is to **characterize, compose, and exploit documented/authorized capabilities efficiently**, not to bypass provider billing, quota, identity, safety, or security enforcement.

Freeze:

```text
maximize permitted capability
!= evade provider controls

sandbox boundary characterization
!= sandbox escape

quota measurement
!= quota bypass

cross-provider orchestration
!= authority laundering

tool availability
!= tool authorization

authenticated identity
!= write authority

write success
!= evidence custody

worker self-report
!= effect receipt
```

Scientific value comes from discovering exactly what is possible under the real environment and account state, including discrepancies between:

- documentation;
- account UI;
- token scope;
- runtime behavior;
- provider billing state;
- model claims;
- observed effects.

---

# 2. Current admitted reality

## 2.1 Proven in the Qwen lane

The current experiment has demonstrated:

```text
sandbox package installation
= PASS

pip / venv / curl / git
= PASS

Hermes scaffold
= PRESENT

HF authenticated read path
= PASS

HF bucket discovery
= PASS

owned bucket upload
= PASS

owned dataset repository creation
= PASS

"HF Pro required for ordinary owned-resource write"
= FALSIFIED

split HF environment
= PASS

system huggingface_hub
= 0.36.2

HF admin/transfer venv huggingface_hub
= 1.30.0

global hub upgrade can break pinned Transformers stack
= OBSERVED

restoration by environment separation
= OBSERVED

/data pressure and cleanup requirement
= OBSERVED

/root overlay as large hot-cache surface
= OBSERVED
```

Use the narrower phrase:

```text
OWNED_RESOURCE_WRITE
= VERIFIED
```

Do not promote this to:

```text
GENERAL_HF_WRITE_AUTHORITY
```

until each resource class is tested.

---

# 3. Account-specific state vs public HF baseline

This lane must preserve two kinds of truth separately.

## A. Operator-observed account state

The operator reports:

```text
ZeroGPU account UI entitlement
≈ 40 minutes/day

backing GPU
= Blackwell-class ZeroGPU

HF account
= small outstanding billing/debt condition may exist

HF Jobs
= may therefore be blocked or unavailable

owned bucket/repo write
= working

large existing bucket corpus
= accessible
```

These are **account observations** and should be verified by lane receipts, not replaced by generic pricing documentation.

## B. Current public Hugging Face baseline

As of 2026-09-08, public HF documentation states:

```text
ZeroGPU unauthenticated
= 2 min/day

ZeroGPU Free
= 5 min/day

ZeroGPU PRO
= 40 min/day

ZeroGPU Team member
= 40 min/day

ZeroGPU Enterprise member
= 60 min/day
```

ZeroGPU currently uses NVIDIA RTX Pro 6000 Blackwell capacity:

```text
large
= 48 GB VRAM
= half RTX Pro 6000 Blackwell

xlarge
= 96 GB VRAM
= full RTX Pro 6000 Blackwell
```

Therefore:

```text
ACCOUNT_OBSERVED_ZERO_GPU_QUOTA
= 40 min/day

PUBLIC_GENERIC_FREE_QUOTA
= 5 min/day

WHY ACCOUNT HAS 40 MIN
= UNKNOWN until entitlement/source is receipted
```

Possible explanations include organization membership or another account-specific entitlement. Do not infer.

Official reference:
https://huggingface.co/docs/hub/spaces-zerogpu

---

# 4. CPU Spaces reality

Current public HF documentation describes CPU Basic as:

```text
2 vCPU
16 GB RAM
50 GB ephemeral disk
hardware hourly price = FREE
```

Important caveats:

```text
FREE CPU HARDWARE
!= infinite guaranteed service

free hardware
= may suspend after inactivity

Space creation eligibility
= plan/account dependent

Static Spaces
= free

ordinary Gradio / Docker Space creation
= currently documented as requiring a paid plan

ZeroGPU
= special free-personal-account exception when eligible
```

Therefore the lane should use:

```text
ZERO_COST_CPU_BASIC_WHEN_ELIGIBLE
```

rather than:

```text
INFINITE FREE CPU
```

The scientific question is whether **this account** can create/run/restart the required CPU Basic/ZeroGPU surfaces, not what a generic plan table says.

Official references:
https://huggingface.co/docs/hub/en/spaces-overview
https://huggingface.co/docs/hub/spaces-gpus

---

# 5. Jobs reality

HF Jobs are a separate commercial/execution plane.

Current public documentation gives PAYG prices such as:

```text
cpu-basic
= $0.01/hour

A10G / L4 / L40S / A100 etc.
= hardware-specific PAYG
```

Jobs require a usable billing/credit state.

The operator reports a small account debt may exist.

Therefore:

```text
HF_JOBS
= DO NOT ASSUME AVAILABLE

JOB CAPABILITY
= test admission only

if billing/credit blocks execution:
    record BILLING_BLOCKED
    do not attempt workaround/evasion
```

Jobs are not required for this lane to be valuable because:

```text
A100 lane
+ ZeroGPU
+ CPU/Space surfaces
+ Buckets
+ external model APIs
```

already provide substantial experimental capability.

Official references:
https://huggingface.co/docs/hub/jobs-pricing
https://huggingface.co/docs/huggingface_hub/guides/jobs

---

# 6. Storage architecture

Preserve the three-tier design, but tighten its semantics.

```text
TIER H — HOT CACHE
/root/nexus_models
/root overlay

role:
- active models
- temporary downloads
- build caches
- current experiment artifacts

authority:
- mutable
- non-custodial
```

```text
TIER R — RUNTIME
/data/NEXUS
30 GB JuiceFS

role:
- live services
- checkpoints needed by active runtime
- current exports
- runtime receipts

policy:
- strict capacity discipline
- avoid generic HF caches
- avoid bulk corpora
```

```text
TIER C — HF COLD / WORKING STORAGE
hf://buckets/<owner>/<bucket>

role:
- large corpora
- checkpoint staging/backups
- intermediate artifacts
- shared multi-agent working storage

properties:
- mutable
- Xet-backed
- not versioned like Git repos
- not evidence custody
```

Promotion rule:

```text
HF BUCKET
= A1 mutable artifact plane

ARCHIVIST / R0
= custody plane

bucket copy
!= custody acceptance
```

Public HF documentation confirms Storage Buckets are mutable, non-versioned, Xet-backed, available to all users/organizations, and designed for checkpoints, logs, intermediate artifacts and agentic storage.

Official reference:
https://huggingface.co/docs/hub/storage-buckets

---

# 7. Split-environment invariant

The most important implementation lesson so far:

```text
ML RUNTIME ENVIRONMENT
!= HF ADMIN / TRANSFER ENVIRONMENT
```

Freeze:

```text
system Python / ML stack
huggingface_hub == 0.36.2
Transformers == 4.44.2
```

and:

```text
/root/hfvenv
huggingface_hub == 1.30.0
new hf CLI
bucket commands
admin / transfer operations
```

Required code behavior:

```python
HFBUCKET_CLI = os.environ["HFBUCKET_CLI"]
```

Fail closed if the configured executable is absent.

Do not silently fall back to generic:

```text
hf
```

from `$PATH`.

Acceptance:

```text
resolved CLI path
= /root/hfvenv/bin/hf

admin CLI version
= 1.30.0

system ML import
= PASS after every admin tooling change
```

---

# 8. Current bridge truth audit

The current `hf_nexus_bridge.py` is a useful scaffold, not a production bridge.

## B1 — CLI resolution defect

Current code uses:

```python
self.cli_path = "hf"
```

while the environment design says:

```text
HFBUCKET_CLI=/root/hfvenv/bin/hf
```

Repair required.

---

## B2 — fake MCP audit delivery

Current `_log_to_mcp()` prints:

```text
[MCP LOG] ...
```

but does not actually call GROSS-AUDITOR.

Therefore:

```text
MCP_AUDIT_DELIVERY
= NOT_IMPLEMENTED
```

Required effect:

```text
bridge event
→ real MCP audit_log/evidence tool call
→ tool receipt
→ returned event/receipt ID
```

Console output remains diagnostic only.

---

## B3 — fake A2A delegation success

Current `delegate_to_agent()`:

- creates a local payload;
- prints/logs it;
- returns a generated `TASK_*`;
- reports `status="published"`.

No real publication transport is proven.

Therefore:

```text
A2A_DELEGATION
= NOT_IMPLEMENTED
```

Required effect:

```text
publish
→ remote channel
→ retrieve on independent agent
→ correlate task ID
→ remote ack
→ result return
```

---

## B4 — Jobs adapter not validated

The current code constructs:

```text
hf jobs run <script>
```

with ad-hoc requirements/mount flags.

Current HF guidance distinguishes Docker-image/command jobs and `hf jobs uv run` / Python APIs for local scripts.

Therefore:

```text
run_remote_job()
= SCAFFOLD
= NOT_VALIDATED
```

Do not use it for billing-sensitive execution until validated.

---

## B5 — stale Space/ZeroGPU model

The current architecture document mentions:

```text
zero-a10g
zero-a100
```

Current ZeroGPU is Blackwell-backed dynamic allocation and compatible with Gradio.

Replace obsolete hardware assumptions with capability-level language:

```text
ZEROGPU_LARGE
ZEROGPU_XLARGE
```

and retrieve actual runtime hardware in receipts.

---

# 9. Security / credential policy

The current workspace has contained literal credentials in `.env` and Markdown/status artifacts.

The operator intends to rotate and purge these credentials.

The lane must still adopt a clean permanent rule:

```text
raw secret
= NEVER committed
= NEVER placed in status/report Markdown
= NEVER echoed by probes
= NEVER sent to model context unless strictly required

documentation
= ${TOKEN_NAME} placeholders only

lane token
= one credential per application/lane where practical

write token
= minimum required resource scope

temporary probe token
= short-lived / rotated after experiment
```

Token rotation is a hygiene task, not a reason to invalidate already captured non-secret experiment results.

---

# 10. Capability-admission matrix

Every surface must be tested independently.

| Capability | State now | Required proof |
|---|---|---|
| HF anonymous read | PASS | known public object retrieved |
| HF authenticated read | PASS | private/owned readable object |
| Owned bucket list | PASS | listing receipt |
| Owned bucket write | PASS | write→readback→hash |
| Owned bucket delete | UNTESTED | delete→absence |
| Bucket sync | PARTIAL | small controlled directory |
| Bucket `--delete` | HOLD | destructive fixture only |
| Owned dataset repo create | PASS | repo existence |
| Repo file push | VERIFY | push→readback→commit |
| Org resource write | UNKNOWN | one owned fixture per org role |
| Gated model read | BLOCKED/UNADMITTED | website grant + read |
| Static Space create | UNTESTED | create→HTTP |
| CPU Basic Space | ACCOUNT-DEPENDENT | create/run/restart |
| ZeroGPU Space host | ACCOUNT-DEPENDENT | own Gradio fixture |
| ZeroGPU use | AVAILABLE | quota + GPU receipt |
| HF Jobs | BILLING-DEPENDENT | tiny CPU admission job |
| HF Sandbox | UNTESTED | create→run→destroy |
| HF MCP read | UNTESTED/LIKELY | actual tool receipt |
| HF MCP write | UNTESTED | tiny owned write fixture |
| NEXUS MCP audit | CONNECTED CLIENT EXISTS | real audit receipt |
| Qwen→HuggingChat A2A | NOT IMPLEMENTED | send/receive/ack |
| HuggingChat→bucket delegated write | UNTESTED | correlated effect receipt |

No row inherits PASS from another row.

---

# 11. Boundary-characterization program

This is the main research value of the Qwen browser sandbox.

The objective is not “escape the sandbox.”

The objective is:

> **Determine the actual documented and observed capability envelope, persistence model, resource ceilings, network behavior and cross-service composition available to an authorized agent.**

## QSBX-BOUNDARY-01 — Filesystem

Measure:

```text
writable roots
read-only roots
ephemeral roots
persistent roots across sessions
maximum practical file sizes
inode/file-count behavior
mount identity
reboot/session reset behavior
```

Use synthetic files only.

---

## QSBX-BOUNDARY-02 — Process/runtime

Measure:

```text
process lifetime
background-process persistence
shell timeout behavior
PTY behavior
signal handling
open-port allowance
local IPC
service restart persistence
```

No privilege-escalation attempts.

---

## QSBX-BOUNDARY-03 — Network

Measure:

```text
DNS
HTTPS egress
WebSocket
SSE
MCP
large upload/download behavior
connection lifetime
rate limiting
destination restrictions
tunnel viability where permitted
```

Use owned endpoints or public benign services.

---

## QSBX-BOUNDARY-04 — Package/toolchain

Measure:

```text
pip
venv
npm/node if present
git
hf CLI
MCP clients
binary installation
compiler/toolchain availability
version persistence
```

Preserve ML/admin dependency separation.

---

## QSBX-BOUNDARY-05 — State persistence

Across new Qwen sessions, determine:

```text
filesystem persistence
environment-variable persistence
git workspace persistence
venv persistence
database persistence
agent/Hermes state persistence
credential cache persistence
background services
```

This is high-value for NEXUS continuity research.

---

# 12. ZeroGPU experiment program

Because the operator observes 40 min/day, ZeroGPU should be treated as a scarce accelerator rather than general compute.

Use it for burst workloads that benefit from:

```text
48/96 GB VRAM
short inference
model conversion checks
embedding batches
quantized validation
small evaluation sweeps
image/audio generation
GPU-only library compatibility probes
```

Avoid:

```text
long training runs
idle model residency
CPU-heavy preprocessing
downloads inside GPU time
dependency compilation during GPU allocation
```

Pre-stage:

```text
models/data in bucket
dependencies in Space image/build
CPU preprocessing before GPU function
```

Then measure:

```text
quota before
queue delay
allocation time
GPU identity
VRAM
function wall time
quota charged
quota after
```

Use the operator-observed 40-minute entitlement as the live source of truth for this account, while retaining the public tier table as external reference.

---

# 13. CPU / Space experiment program

The goal is to determine whether Spaces can serve as durable low-cost coordination surfaces.

Candidate uses:

```text
read-only dashboards
artifact browsers
MCP front ends
search/index UIs
queue viewers
evaluation result explorers
small CPU APIs
webhook receivers
control-plane observability
```

Test:

```text
Space creation entitlement
cold-start time
idle suspension
restart behavior
filesystem persistence
secret injection
bucket mounts
HTTP API stability
build cache
resource ceilings
```

Never make a Space the NEXUS authority kernel.

---

# 14. A100 + Qwen division of labor

Do not duplicate both lanes.

```text
A100 / CLINE
= GPU forge
= training
= heavyweight eval
= artifact producer
= controlled model conversion

QWEN SANDBOX / HERMES
= orchestration laboratory
= provider routing
= HF control-plane tests
= storage / Spaces / MCP
= lightweight analysis
= experiment coordination

HF BUCKETS
= shared mutable exchange

NEXUS
= task/authority/evidence adjudication
```

Recommended flow:

```text
NEXUS TaskEnvelope
      ↓
Qwen planner / coordinator
      ↓
A100 GPU task
      ↓
artifact + SHA-256
      ↓
HF bucket staging
      ↓
Qwen/Hermes downstream analysis
      ↓
independent verifier
      ↓
NEXUS acceptance
```

---

# 15. Multi-agent provider research

Hermes routing should be tested as a scientific object.

Do not call a provider “working” merely because an API returns one response.

For each provider/model record:

```text
provider
model
auth class
pricing/quota class
context limit
tool calling
JSON/schema reliability
latency p50/p95
error rate
rate-limit behavior
streaming
long-session stability
fallback behavior
task classes
```

Recommended worker roles:

```text
Cerebras/Qwen
= fast planning / code / synthesis candidate

Groq/Qwen
= fast independent comparison candidate

HF/HuggingChat agent
= HF-native tool worker candidate

A100 local/open model
= reproducible local worker

frontier cloud reviewer
= bounded escalation
```

Do not let Hermes routing increase any worker's authority.

---

# 16. Evidence and telemetry contract

Every consequential experiment should produce:

```text
ExperimentReceipt

experiment_id
lane
timestamp
worker
provider/model
runtime image/version
effective credential class
resource target
precondition
command/tool intent
tool receipt
effect observation
artifact path
artifact SHA-256
network/remote acknowledgement if applicable
cost/quota delta if measurable
result
claim ceiling
open uncertainties
```

Example claim ceilings:

```text
API_RETURNED_SUCCESS
< REMOTE_OBJECT_OBSERVED
< REMOTE_OBJECT_READBACK_HASH_MATCH
< INDEPENDENT_SECOND-LANE_VERIFIED
```

For storage:

```text
UPLOAD_REQUEST
!= REMOTE_ACCEPT
!= READBACK
!= CUSTODY
```

---

# 17. Experiment queue

## Phase Q0 — Truth repair

1. purge/rotate secrets when operator schedules it;
2. replace raw credentials in Markdown with placeholders;
3. reconcile stale "Pro required" claims;
4. fix `HFBUCKET_CLI` resolution;
5. make status report machine-derived where possible.

**Exit:** no contradictory current-state documentation.

---

## Phase Q1 — Bridge truth

Implement real:

```text
MCP audit delivery
A2A publish
A2A retrieve
remote ack
effect receipt
```

Validate `run_remote_job` against current HF CLI/API or leave disabled.

**Exit:** no success-shaped stub functions.

---

## Phase Q2 — HF capability census

Execute the capability matrix with tiny fixtures.

Priority:

```text
repo push
bucket delete fixture
Space create
ZeroGPU own fixture
HF MCP read/write
Jobs admission
Sandbox admission
```

**Exit:** each capability = PASS / FAIL / BLOCKED / UNKNOWN with receipt.

---

## Phase Q3 — Sandbox boundary map

Run BOUNDARY-01…05.

**Exit:** a reproducible capability envelope for the Qwen browser sandbox.

---

## Phase Q4 — Cross-node agent fabric

Implement:

```text
Qwen ↔ NEXUS MCP
Qwen ↔ HF
Qwen ↔ A100
Qwen ↔ HuggingChat/HF agent
```

with real message and effect correlation.

**Exit:** one end-to-end bounded task completed with independent receipts.

---

## Phase Q5 — Long-run reliability

Run 6h / 24h / 72h experiments:

```text
service survival
credential renewal
bucket sync correctness
provider fallback
Hermes queue integrity
duplicate-task suppression
cost/quota tracking
artifact consistency
```

No production promotion from a short smoke test.

---

# 18. Promotion gate

This lane may become a `PRODUCTION_BRIDGE_CANDIDATE` only if:

```text
secret hygiene
= PASS

bridge success stubs
= eliminated

MCP audit
= real

A2A
= real

write/read/delete semantics
= receipted

Space/ZeroGPU semantics
= characterized

Jobs
= either PASS or explicitly BILLING_BLOCKED

sandbox capability envelope
= documented

evidence/custody distinction
= preserved

failure/retry/idempotency
= tested

24h minimum burn-in
= completed

no hidden authority promotion
= verified
```

Even then:

```text
PRODUCTION_BRIDGE_CANDIDATE
!= NEXUS AUTHORITY
```

---

# 19. Current status freeze

```text
NEXUS-QWEN-HF-SANDBOX-01

CLASS
= CLOCK-B EXPERIMENTAL FABRIC

STATE
= OPERATIONAL
= OWNED-RESOURCE WRITE VERIFIED
= NOT PRODUCTION-ADMITTED

HF-WRITE-DIFF-00
= PASS

PRO PURCHASE
= NOT REQUIRED for currently tested bucket/repo write workflow

ACCOUNT-OBSERVED ZEROGPU
= 40 MIN/DAY
= BLACKWELL CLASS

PUBLIC GENERIC FREE ZEROGPU
= 5 MIN/DAY

REASON FOR 40-MIN ACCOUNT ENTITLEMENT
= UNKNOWN / TO RECEIPT

HF JOBS
= POSSIBLY BILLING-BLOCKED
= NOT REQUIRED FOR CONTINUED EXPERIMENTATION

CPU BASIC
= ZERO-COST HARDWARE WHEN ELIGIBLE
= NOT AN INFINITE-SLA CLAIM

A100
= INDEPENDENT GPU FORGE

HF BUCKET
= MUTABLE ARTIFACT PLANE
= NOT CUSTODY

NEXT
= Q0 TRUTH REPAIR
→ Q1 BRIDGE TRUTH
→ Q2 CAPABILITY CENSUS
→ Q3 BOUNDARY MAP
→ Q4 CROSS-NODE FABRIC
→ Q5 BURN-IN
```

---

# 20. References

Primary Hugging Face documentation checked 2026-09-08:

- Storage Buckets  
  https://huggingface.co/docs/hub/storage-buckets

- Storage Bucket security/access model  
  https://huggingface.co/docs/hub/storage-buckets-security

- ZeroGPU  
  https://huggingface.co/docs/hub/spaces-zerogpu

- Spaces overview / hardware  
  https://huggingface.co/docs/hub/en/spaces-overview

- GPU Spaces / billing lifecycle  
  https://huggingface.co/docs/hub/spaces-gpus

- Jobs pricing  
  https://huggingface.co/docs/hub/jobs-pricing

- Jobs execution  
  https://huggingface.co/docs/huggingface_hub/guides/jobs

- User access tokens  
  https://huggingface.co/docs/hub/security-tokens
