# NEXUS Qwen/HF Sandbox Advisory Packet

Files:

1. `NEXUS_QWEN_HF_SANDBOX_EXPERIMENTAL_LANE_ADVISORY_2026-09-08.md`
   - governing advisory
   - corrected HF entitlement model
   - capability matrix
   - architecture
   - promotion gates

2. `QWEN_CODER_QSBX_FABRIC_02_MISSION_2026-09-08.md`
   - copy/paste long-run Qwen mission
   - truth repair
   - real MCP/A2A
   - HF capability census
   - ZeroGPU measurement
   - sandbox boundary map
   - A100/HF cross-node experiment

The packet intentionally excludes all live API/HF tokens.
